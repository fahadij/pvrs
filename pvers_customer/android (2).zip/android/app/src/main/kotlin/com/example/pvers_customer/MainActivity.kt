package com.example.pvers_customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
