
/*class Value {
  static String ID;
  static void setString(String newValue) {
    ID = newValue;
  }
*/
